﻿namespace com.tweetapp.service
{
    public class LikedUserView
    {
        public string UserId { get; set; }
    }
}