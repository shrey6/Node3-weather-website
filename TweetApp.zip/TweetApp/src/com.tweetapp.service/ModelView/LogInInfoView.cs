﻿namespace com.tweetapp.service
{
    public class LogInInfoView
    {
        public string JwtToken { get; set; }
        public string Name { get; set; }
        public string UserNameId { get; set; }
        public string Gender { get; set; }

    }
}
